<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">GIPHY</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo e(route('home')); ?>">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="<?php echo e(route('categories')); ?>">Categories <span class="sr-only">(current)</span></a>
                        </li>
                    </ul>
                   
                </div>
            </nav>
        </div>
    </div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search', [])->html();
} elseif ($_instance->childHasBeenRendered('YKVb7Nq')) {
    $componentId = $_instance->getRenderedChildComponentId('YKVb7Nq');
    $componentTag = $_instance->getRenderedChildComponentTagName('YKVb7Nq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YKVb7Nq');
} else {
    $response = \Livewire\Livewire::mount('search', []);
    $html = $response->html();
    $_instance->logRenderedChild('YKVb7Nq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php /**PATH E:\My stuff\Websites\Laravel\Giphy-App\Giphy-laravel-main\Giphy-laravel-main\resources\views/nav.blade.php ENDPATH**/ ?>