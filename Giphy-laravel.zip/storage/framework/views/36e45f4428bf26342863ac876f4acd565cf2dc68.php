<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <h5 class="text-white mt-2">Popular Categories</h5>

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="gif-link-wrap">
                <a href="#" class="link-gif">
                    <img src="<?php echo e($cat['gif']['images']['preview_gif']['url']); ?>" alt="">
                    <span class="title"><?php echo e($cat['name']); ?></span>
                </a>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My stuff\Websites\Laravel\Giphy-App\Giphy-laravel-main\Giphy-laravel-main\resources\views/categories.blade.php ENDPATH**/ ?>