<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <h5 class="text-white mt-4"><?php echo e($Gif['title']); ?></h5>
        <div class="row">
            <div class="col-md-6">
                <img class="w-100 " src="<?php echo e($Gif['images']['original']['url']); ?>" alt="Giphy image">
            </div>
            <div class="col-md-6">
                <div class="row">
                    <?php if(isset($Gif['user'])): ?>
                        <div class="col-md-2">
                            <img class=" user-avatar " src="<?php echo e($Gif['user']['avatar_url']); ?>" alt="Giphy image">
                        </div>
                        <div class="col-md-10">
                            <div class="text-white"> By <?php echo e($Gif['user']['display_name']); ?><br>
                                @ <?php echo e($Gif['user']['username']); ?></div>
                        </div>
                        <div class="col-12">
                            <div class="text-white"> Website <a class=" "
                                    href="<?php echo e($Gif['user']['website_url']); ?>" target="_blank">
                                    <span><?php echo e($Gif['user']['website_url']); ?></span></a> </div>
                        </div>
                    <?php endif; ?>
                </div>


            </div>
        </div>
        <div class="text-center">
            <a class="btn btn-sm btn-secondary mt-3" href="<?php echo e(route('home')); ?>">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My stuff\Websites\Laravel\Giphy-App\Giphy-laravel-main\Giphy-laravel-main\resources\views/detail.blade.php ENDPATH**/ ?>