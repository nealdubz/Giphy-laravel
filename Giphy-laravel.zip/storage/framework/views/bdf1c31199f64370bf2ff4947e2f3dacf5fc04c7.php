<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <h5 class="text-white mt-4">Trending Gifs</h5>
        <div class="row">
            <?php $__currentLoopData = $trendingGifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if (isset($component)) { $__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GifCard::class, ['gif' => $gif]); ?>
<?php $component->withName('gif-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff)): ?>
<?php $component = $__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff; ?>
<?php unset($__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <h5 class="text-white mt-4">Trending Stickers</h5>
        <div class="row">
            <?php $__currentLoopData = $trendingStickersGifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GifCard::class, ['gif' => $gif]); ?>
<?php $component->withName('gif-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff)): ?>
<?php $component = $__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff; ?>
<?php unset($__componentOriginala3ed5cacc8d6a111a072b48bdc050d63a22b43ff); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\My stuff\Websites\Laravel\Giphy-App\Giphy-laravel-main\Giphy-laravel-main\resources\views/home.blade.php ENDPATH**/ ?>