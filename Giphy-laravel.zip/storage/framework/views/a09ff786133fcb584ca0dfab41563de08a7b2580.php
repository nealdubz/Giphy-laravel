<!doctype html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Scripts -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"  ></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH E:\My stuff\Websites\Laravel\Giphy-App\Giphy-laravel-main\Giphy-laravel-main\resources\views/layouts/main.blade.php ENDPATH**/ ?>