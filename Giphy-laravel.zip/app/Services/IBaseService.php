<?php

namespace App\Services;

interface IBaseService
{
    public function GetIndexData();

    public function GetCategories();
}