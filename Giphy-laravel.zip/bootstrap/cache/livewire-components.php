<?php return array (
  'search' => 'App\\Http\\Livewire\\Search',
);