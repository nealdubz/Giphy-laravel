## About Giphy

A Giphy app with search funtionality

## Installation
composer install

npm run dev

php artisan serve
